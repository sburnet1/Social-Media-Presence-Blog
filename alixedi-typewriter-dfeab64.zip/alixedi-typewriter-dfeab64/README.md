typewriter
==========

A simple and beautiful theme for Jekyll.

![Screenshot](https://raw.githubusercontent.com/alixedi/typewriter/master/images/screenshot.png)
